# WorldAtlas 0.3.3 构建状态

本版针对此前 GitHub Actions Kotlin 编译日志进行修复：
- 搜索框使用 `maxLines = 1`，不再引用无法解析的 `singleLine`。
- MapLibre `queryRenderedFeatures` 使用 Kotlin vararg 的正确调用方式：直接传入图层 ID 字符串。

同时修正仓库内 GitHub Actions 工作流：源码压缩包内工程位于 `wa_build/`，构建步骤明确在该目录执行。

版本号：0.3.3（versionCode 7）。

注意：当前制作环境没有 Android SDK，且未完成真实 Gradle APK 构建或真机测试。必须以 GitHub Actions 实际构建结果为准。
