# WorldAtlas 0.3.2 构建状态

本版本针对 GitHub Actions 日志中的两个 Kotlin 编译错误进行修复：

- 搜索框使用 `maxLines = 1`，避免 `singleLine` 属性解析问题。
- MapLibre `queryRenderedFeatures` 显式传入图层 ID 数组 `arrayOf(COUNTRY_FILL_LAYER)`。

版本号：0.3.2（versionCode 6）。

注意：本地环境没有 Android SDK 和 Gradle，因此尚未在本地完成 APK 编译或真机测试。请以 GitHub Actions 的实际构建结果为准。
