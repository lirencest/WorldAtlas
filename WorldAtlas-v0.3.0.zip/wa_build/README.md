# WorldAtlas Android 0.3.0

Native Android 2D world atlas prototype using Kotlin, Android Views and MapLibre Native Android SDK 13.7.1.

## Current capabilities

- MapLibre 2D basemap with OpenFreeMap Liberty and Dark styles
- Online global country polygon GeoJSON source
- Tap a rendered country polygon to show available name and ISO codes
- Selected-country fill and outline highlight
- Search sample countries and currently loaded GeoJSON features
- Two-point straight-line distance measurement
- Temporary custom map markers
- Data, favorites and historical-map screens are still placeholders

## Build locally

Requirements: JDK 17, Android SDK Platform 36, Android Build Tools, and Gradle 8.13. Open the `wa_build` project directory in Android Studio, or run from this directory:

```bash
gradle --no-daemon :app:assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

This archive includes Gradle wrapper configuration but not the wrapper launcher scripts or wrapper JAR. The local command therefore requires Gradle to be installed. The GitHub Actions workflow installs Gradle itself and does not depend on a wrapper JAR.

## Build with GitHub Actions (phone-friendly)

1. Create a GitHub repository and upload the **contents** of the `wa_build` folder (not the outer ZIP folder).
2. Open the repository's **Actions** tab.
3. Select **Build Android APK** and press **Run workflow**.
4. When the run finishes successfully, open its run page and download the `WorldAtlas-0.3.0-debug-apk` artifact.

The workflow is configured but has not been run from this environment. A successful cloud build is not yet confirmed.

## Data limitations

The ten hard-coded country records are demonstration records. Their population and GDP values are illustrative approximations, not verified official statistics. Other countries currently show only properties available in the boundary GeoJSON. A complete, validated country facts database and historical boundary archive are not integrated.

Country boundaries and basemap styles are downloaded at runtime; network access is required. Offline map data is not bundled. Boundary feature property lookup supports common name and ISO aliases, but coverage depends on the upstream dataset.

## Verification status

- ZIP integrity and Android XML parsing: checked when packaging this release.
- MapLibre APIs: checked against the official Android SDK 13.7.1 documentation.
- Android Gradle compilation: **not run** in the current environment because Gradle and Android SDK are unavailable here.
- Device installation/runtime test: **not run**.
