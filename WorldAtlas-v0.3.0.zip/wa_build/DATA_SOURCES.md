# Data sources and limitations

- Basemap style: OpenFreeMap online style endpoints (Liberty / Dark).
- Country polygons: GeoJSON URL configured in `MainActivity.kt`: `https://raw.githubusercontent.com/datasets/geo-countries/main/data/countries.geojson`
- The ten country rows embedded in `MainActivity.kt` are demonstration records only. Population and GDP values are approximate UI placeholders, not verified statistical data.
- Other country names and ISO identifiers are read from available GeoJSON feature properties. A complete validated country facts database and historical boundary archive are not yet integrated.
- Network access is required for map styles and GeoJSON.
