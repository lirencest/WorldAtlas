package com.worldatlas.app

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.graphics.PointF
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setPadding
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.annotations.MarkerOptions
import org.maplibre.android.annotations.PolylineOptions
import org.maplibre.android.style.layers.FillLayer
import org.maplibre.android.style.layers.LineLayer
import org.maplibre.android.style.layers.PropertyFactory
import org.maplibre.android.style.sources.GeoJsonSource
import java.net.URI
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.*

private data class Country(
    val name: String, val english: String, val flag: String, val capital: String,
    val area: Double, val population: String, val gdp: String,
    val lat: Double, val lon: Double
)

class MainActivity : AppCompatActivity() {
    private lateinit var mapView: MapView
    private var map: MapLibreMap? = null
    private lateinit var infoCard: LinearLayout
    private lateinit var search: EditText
    private var darkLayer = false
    private var measureStart: LatLng? = null
    private var measureMode = false
    private var markerCount = 0
    private var selected: Country? = null
    private var countrySource: GeoJsonSource? = null
    private var selectedCountrySource: GeoJsonSource? = null
    private var selectedCountryFeature: org.maplibre.geojson.Feature? = null
    private var countryBoundariesReady = false

    private val countries = listOf(
        Country("中国", "China", "🇨🇳", "北京", 9596961.0, "约 14.1 亿", "约 18.7 万亿美元", 35.86, 104.20),
        Country("日本", "Japan", "🇯🇵", "东京", 377975.0, "约 1.24 亿", "约 4.0 万亿美元", 36.20, 138.25),
        Country("美国", "United States", "🇺🇸", "华盛顿", 9833517.0, "约 3.4 亿", "约 30.5 万亿美元", 39.50, -98.35),
        Country("巴西", "Brazil", "🇧🇷", "巴西利亚", 8515767.0, "约 2.12 亿", "约 2.2 万亿美元", -10.0, -55.0),
        Country("法国", "France", "🇫🇷", "巴黎", 551695.0, "约 6800 万", "约 3.2 万亿美元", 46.2, 2.2),
        Country("澳大利亚", "Australia", "🇦🇺", "堪培拉", 7692024.0, "约 2700 万", "约 1.8 万亿美元", -25.3, 133.8),
        Country("印度", "India", "🇮🇳", "新德里", 3287263.0, "约 14.5 亿", "约 4.2 万亿美元", 22.0, 79.0),
        Country("加拿大", "Canada", "🇨🇦", "渥太华", 9984670.0, "约 4100 万", "约 2.2 万亿美元", 56.1, -106.3),
        Country("俄罗斯", "Russia", "🇷🇺", "莫斯科", 17098246.0, "约 1.44 亿", "约 2.2 万亿美元", 61.5, 105.3),
        Country("英国", "United Kingdom", "🇬🇧", "伦敦", 243610.0, "约 6900 万", "约 3.7 万亿美元", 55.4, -3.4)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MapLibre.getInstance(this)
        buildScreen(savedInstanceState)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun text(value: String, size: Float, color: Int = Color.rgb(32, 43, 55), bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun buildScreen(savedInstanceState: Bundle?) {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(247, 248, 250)) }
        mapView = MapView(this)
        root.addView(mapView, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        mapView.onCreate(savedInstanceState)
        mapView.getMapAsync { mapbox ->
            map = mapbox
            mapbox.cameraPosition = CameraPosition.Builder().target(LatLng(20.0, 0.0)).zoom(1.35).build()
            mapbox.setStyle("https://tiles.openfreemap.org/styles/liberty") { style ->
                addCountryBoundaries(style)
            }
            mapbox.addOnMapClickListener { point ->
                if (!measureMode) handleCountryTap(point)
                true
            }
            mapbox.addOnMapLongClickListener { point ->
                if (measureMode) handleMeasure(point) else addCustomMarker(point)
                true
            }
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16)); setBackgroundColor(Color.TRANSPARENT)
        }
        val titleRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val titleCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        titleCol.addView(text("WorldAtlas", 23f, Color.rgb(34, 55, 76), true))
        titleCol.addView(text("探索世界 · 认识每一个国家", 12f, Color.rgb(105, 119, 132)))
        titleRow.addView(titleCol)
        val layerBtn = button("图层") { toggleLayer() }
        titleRow.addView(layerBtn)
        top.addView(titleRow)

        search = EditText(this).apply {
            hint = "搜索国家 / Search country"
            textSize = 15f
            singleLine = true
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setBackgroundColor(Color.WHITE)
            elevation = dp(4).toFloat()
        }
        val searchRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(12), 0, 0)
        }
        searchRow.addView(search, LinearLayout.LayoutParams(0, dp(50), 1f))
        val go = button("搜索") { doSearch() }
        val goParams = LinearLayout.LayoutParams(dp(72), dp(50)); goParams.marginStart = dp(8)
        searchRow.addView(go, goParams)
        top.addView(searchRow)
        root.addView(top, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        val rightControls = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(6)); setBackgroundColor(Color.WHITE); elevation = dp(4).toFloat() }
        rightControls.addView(button("＋") { map?.animateCamera(CameraUpdateFactory.zoomIn()) })
        rightControls.addView(button("－") { map?.animateCamera(CameraUpdateFactory.zoomOut()) })
        rightControls.addView(button("测距") { measureMode = !measureMode; measureStart = null; toast(if (measureMode) "测距已开启：长按地图选择起点" else "测距已关闭") })
        val rc = FrameLayout.LayoutParams(dp(64), -2, Gravity.END or Gravity.CENTER_VERTICAL); rc.setMargins(0, 0, dp(14), dp(26))
        root.addView(rightControls, rc)

        infoCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16)); setBackgroundColor(Color.WHITE); elevation = dp(7).toFloat()
        }
        showCountry(null)
        val infoParams = FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM)
        infoParams.setMargins(dp(14), 0, dp(14), dp(82))
        root.addView(infoCard, infoParams)

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setBackgroundColor(Color.WHITE); elevation = dp(12).toFloat(); setPadding(dp(4), dp(8), dp(4), dp(8))
        }
        listOf("地图", "数据", "收藏", "设置").forEach { label ->
            val b = TextView(this).apply {
                text = label; textSize = 13f; gravity = Gravity.CENTER; setTextColor(Color.rgb(60, 83, 105)); setPadding(dp(8), dp(8), dp(8), dp(8))
                setOnClickListener { when (label) {
                    "地图" -> toast("地图模式")
                    "数据" -> showDataDialog()
                    "收藏" -> showSavedDialog()
                    else -> showSettingsDialog()
                } }
            }
            nav.addView(b, LinearLayout.LayoutParams(0, dp(44), 1f))
        }
        root.addView(nav, FrameLayout.LayoutParams(-1, dp(64), Gravity.BOTTOM))
    }

    private fun button(label: String, action: () -> Unit) = TextView(this).apply {
        text = label; textSize = 14f; gravity = Gravity.CENTER; setTextColor(Color.rgb(45, 75, 103))
        setPadding(dp(10), dp(9), dp(10), dp(9)); setBackgroundColor(Color.WHITE); elevation = dp(2).toFloat()
        setOnClickListener { action() }
    }

    private fun doSearch() {
        val q = search.text.toString().trim()
        val country = countries.firstOrNull { it.name.equals(q, true) || it.english.equals(q, true) || it.name.contains(q, true) || it.english.contains(q, true) }
        if (country != null) {
            selected = country
            map?.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(country.lat, country.lon), 3.5), 900)
            showCountry(country)
            return
        }
        val feature = countrySource?.querySourceFeatures(null)?.firstOrNull { f ->
            val name = countryName(f)
            name.equals(q, true) || name.contains(q, true)
        }
        if (feature != null) {
            val name = countryName(feature).ifBlank { q }
            val a2 = countryCode(feature, "ISO3166-1-Alpha-2", "ISO_A2")
            val a3 = countryCode(feature, "ISO3166-1-Alpha-3", "ISO_A3")
            highlightCountry(feature)
            showBoundaryCountry(name, a2, a3)
            toast("已找到 $name")
        } else {
            toast(if (countryBoundariesReady) "没有找到这个国家，请尝试英文名称" else "全球国家边界仍在加载，请稍后再试")
        }
    }

    private fun showCountry(country: Country?) {
        infoCard.removeAllViews()
        if (country == null) {
            infoCard.addView(text("世界地图", 17f, Color.rgb(37, 61, 84), true))
            infoCard.addView(text("点击搜索国家，或长按地图添加自定义标记。", 13f, Color.rgb(105, 119, 132)))
        } else {
            infoCard.addView(text("${country.flag}  ${country.name}  ·  ${country.english}", 17f, Color.rgb(37, 61, 84), true))
            infoCard.addView(text("首都：${country.capital}     面积：${NumberFormat.getNumberInstance(Locale.US).format(country.area.toLong())} km²", 13f))
            infoCard.addView(text("人口：${country.population}     GDP：${country.gdp}", 13f, Color.rgb(95, 111, 126)))
            infoCard.addView(text("注：人口和 GDP 为界面演示用近似值，正式版将接入可追溯的数据源。", 10f, Color.rgb(135, 145, 155)))
        }
    }

    private fun addCountryBoundaries(style: org.maplibre.android.maps.Style) {
        try {
            val source = GeoJsonSource(
                COUNTRY_SOURCE_ID,
                URI(COUNTRY_GEOJSON_URL)
            )
            style.addSource(source)
            countrySource = source
            val selectedSource = GeoJsonSource(SELECTED_COUNTRY_SOURCE_ID)
            style.addSource(selectedSource)
            selectedCountrySource = selectedSource
            val fill = FillLayer(COUNTRY_FILL_LAYER, COUNTRY_SOURCE_ID).withProperties(
                PropertyFactory.fillColor(Color.rgb(186, 207, 218)),
                PropertyFactory.fillOpacity(0.10f),
                PropertyFactory.fillAntialias(true)
            )
            val outline = LineLayer(COUNTRY_LINE_LAYER, COUNTRY_SOURCE_ID).withProperties(
                PropertyFactory.lineColor(Color.rgb(104, 129, 146)),
                PropertyFactory.lineWidth(0.7f),
                PropertyFactory.lineOpacity(0.85f)
            )
            val selectedFill = FillLayer(SELECTED_COUNTRY_FILL_LAYER, SELECTED_COUNTRY_SOURCE_ID).withProperties(
                PropertyFactory.fillColor(Color.rgb(54, 139, 205)),
                PropertyFactory.fillOpacity(0.32f),
                PropertyFactory.fillAntialias(true)
            )
            val selectedOutline = LineLayer(SELECTED_COUNTRY_LINE_LAYER, SELECTED_COUNTRY_SOURCE_ID).withProperties(
                PropertyFactory.lineColor(Color.rgb(28, 104, 173)),
                PropertyFactory.lineWidth(2.2f),
                PropertyFactory.lineOpacity(1.0f)
            )
            style.addLayer(fill)
            style.addLayer(outline)
            style.addLayer(selectedFill)
            style.addLayer(selectedOutline)
            selectedCountryFeature?.let { selectedSource.setGeoJson(it) }
            countryBoundariesReady = true
        } catch (e: Exception) {
            countryBoundariesReady = false
            toast("国家边界加载失败，请检查网络后重试")
        }
    }

    private fun handleCountryTap(point: LatLng) {
        val screenPoint = map?.projection?.toScreenLocation(point) ?: return
        val feature = map?.queryRenderedFeatures(screenPoint, arrayOf(COUNTRY_FILL_LAYER))?.firstOrNull() ?: return
        val name = countryName(feature).ifBlank { "未知地区" }
        val a2 = countryCode(feature, "ISO3166-1-Alpha-2", "ISO_A2")
        val a3 = countryCode(feature, "ISO3166-1-Alpha-3", "ISO_A3")
        highlightCountry(feature)
        val known = countries.firstOrNull { it.english.equals(name, true) }
        if (known != null) showCountry(known) else showBoundaryCountry(name, a2, a3)
    }

    private fun highlightCountry(feature: org.maplibre.geojson.Feature) {
        try {
            selectedCountryFeature = feature
            selectedCountrySource?.setGeoJson(feature)
        } catch (_: Exception) {
            toast("国家高亮暂时不可用，请稍后重试")
        }
    }

    private fun countryName(feature: org.maplibre.geojson.Feature): String {
        return sequenceOf("name", "NAME", "ADMIN", "name_en", "NAME_EN", "NAME_LONG", "SOVEREIGNT", "FORMAL_EN")
            .mapNotNull { key -> runCatching { feature.getStringProperty(key) }.getOrNull() }
            .firstOrNull { it.isNotBlank() } ?: ""
    }

    private fun countryCode(feature: org.maplibre.geojson.Feature, primary: String, fallback: String): String {
        val aliases = when (primary) {
            "ISO3166-1-Alpha-2" -> listOf(primary, fallback, "ISO_A2_EH", "WB_A2")
            else -> listOf(primary, fallback, "ADM0_A3", "SOV_A3")
        }
        return aliases.distinct()
            .mapNotNull { key -> runCatching { feature.getStringProperty(key) }.getOrNull() }
            .firstOrNull { it.isNotBlank() && it != "-99" } ?: ""
    }

    private fun showBoundaryCountry(name: String, alpha2: String, alpha3: String) {
        infoCard.removeAllViews()
        infoCard.addView(text(name, 18f, Color.rgb(37, 61, 84), true))
        infoCard.addView(text("国家 / 地区边界数据已匹配", 13f, Color.rgb(75, 96, 113)))
        infoCard.addView(text("ISO 代码：${alpha2.ifBlank { "暂无" }} · ${alpha3.ifBlank { "暂无" }}", 12f, Color.rgb(95, 111, 126)))
        infoCard.addView(text("人口、GDP、首都和面积统计尚未接入统一数据源。", 10f, Color.rgb(135, 145, 155)))
    }

    private fun toggleLayer() {
        darkLayer = !darkLayer
        map?.setStyle(if (darkLayer) "https://tiles.openfreemap.org/styles/dark" else "https://tiles.openfreemap.org/styles/liberty") { style ->
            addCountryBoundaries(style)
        }
        toast(if (darkLayer) "已切换深色图层" else "已切换简洁地图图层")
    }

    private fun handleMeasure(point: LatLng) {
        val first = measureStart
        if (first == null) {
            measureStart = point
            map?.addMarker(MarkerOptions().position(point).title("测距起点"))
            toast("起点已记录，再长按地图选择终点")
        } else {
            val km = distanceKm(first, point)
            map?.addMarker(MarkerOptions().position(point).title("测距终点"))
            map?.addPolyline(PolylineOptions().add(first, point).width(3f).color(Color.rgb(40, 115, 190)))
            AlertDialog.Builder(this).setTitle("距离测量").setMessage("两点直线距离约 ${String.format(Locale.US, "%,.1f", km)} 公里。")
                .setPositiveButton("完成") { _, _ -> measureStart = null; measureMode = false }.show()
        }
    }

    private fun distanceKm(a: LatLng, b: LatLng): Double {
        val r = 6371.0088
        val lat1 = Math.toRadians(a.latitude); val lat2 = Math.toRadians(b.latitude)
        val dLat = lat2 - lat1; val dLon = Math.toRadians(b.longitude - a.longitude)
        val h = sin(dLat / 2).pow(2) + cos(lat1) * cos(lat2) * sin(dLon / 2).pow(2)
        return 2 * r * asin(sqrt(h.coerceIn(0.0, 1.0)))
    }

    private fun addCustomMarker(point: LatLng) {
        markerCount++
        map?.addMarker(MarkerOptions().position(point).title("自定义标记 $markerCount").snippet("WorldAtlas 标记点"))
        toast("已添加标记 $markerCount")
    }

    private fun showDataDialog() {
        val choices = arrayOf("国家面积", "人口规模", "GDP 总量")
        AlertDialog.Builder(this).setTitle("数据地图").setItems(choices) { _, which ->
            val label = choices[which]
            AlertDialog.Builder(this).setTitle(label).setMessage("数据着色功能正在开发中。下一阶段会接入统一年份、统一口径的国家统计数据。")
                .setPositiveButton("知道了", null).show()
        }.show()
    }

    private fun showSavedDialog() {
        AlertDialog.Builder(this).setTitle("收藏夹").setMessage("收藏国家和地点功能将在下一阶段加入。\n目前可长按地图添加临时标记。")
            .setPositiveButton("好的", null).show()
    }

    private fun showSettingsDialog() {
        AlertDialog.Builder(this).setTitle("设置").setItems(arrayOf("地图图层", "历史地图", "关于 WorldAtlas")) { _, which ->
            when (which) {
                0 -> toggleLayer()
                1 -> AlertDialog.Builder(this).setTitle("历史地图").setMessage("历史国界时间轴正在规划中，后续会按年份切换国界数据。") .setPositiveButton("知道了", null).show()
                else -> AlertDialog.Builder(this).setTitle("WorldAtlas 0.3.0").setMessage("一款以国家探索和地理数据为核心的世界地图 App。地图底图使用 OpenFreeMap / OpenStreetMap 生态。") .setPositiveButton("关闭", null).show()
            }
        }.show()
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    companion object {
        private const val COUNTRY_SOURCE_ID = "world-country-polygons"
        private const val COUNTRY_FILL_LAYER = "world-country-fill"
        private const val COUNTRY_LINE_LAYER = "world-country-outline"
        private const val SELECTED_COUNTRY_SOURCE_ID = "world-country-selected-source"
        private const val SELECTED_COUNTRY_FILL_LAYER = "world-country-selected-fill"
        private const val SELECTED_COUNTRY_LINE_LAYER = "world-country-selected-outline"
        // Natural Earth 10m Admin-0 country polygons, distributed as GeoJSON.
        private const val COUNTRY_GEOJSON_URL = "https://raw.githubusercontent.com/datasets/geo-countries/main/data/countries.geojson"
    }

    override fun onStart() { super.onStart(); mapView.onStart() }
    override fun onResume() { super.onResume(); mapView.onResume() }
    override fun onPause() { mapView.onPause(); super.onPause() }
    override fun onStop() { mapView.onStop(); super.onStop() }
    override fun onLowMemory() { super.onLowMemory(); mapView.onLowMemory() }
    override fun onDestroy() { mapView.onDestroy(); super.onDestroy() }
    override fun onSaveInstanceState(outState: Bundle) { super.onSaveInstanceState(outState); mapView.onSaveInstanceState(outState) }
}
